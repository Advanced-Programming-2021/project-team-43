package controller;

import org.junit.Test;

import static org.junit.Assert.*;

public class MonsterEffectTest {

    @Test
    public void changeModeEffectController() {
    }

    @Test
    public void suijin() {
    }

    @Test
    public void marshmallon() {
    }

    @Test
    public void theCalculator() {
    }

    @Test
    public void terratiger() {
    }

    @Test
    public void gateGuardian() {
    }

    @Test
    public void beastKingBarbaros() {
    }

    @Test
    public void theTricky() {
    }

    @Test
    public void texchanger() {
    }

    @Test
    public void heraldOfCreation() {
    }
}