package controller;

import model.*;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;

import static org.junit.Assert.*;

public class GameMatControllerTest {

    @Before
    public void beforeAllClassTest() {
        DeckModel deckModel;
        SetCards.readingCSVFileMonster();
        SetCards.readingCSVFileTrapSpell();
        new UserModel("Guy", "123", "me");
        new UserModel("Guy2", "123", "me2");
        MainMenuController.username = "Guy";
        deckModel = new DeckModel("myDeck");
        for (int i = 0; i < 10; i++) {
            deckModel.addCardToMain("Yami");
        }
        for (int i = 0; i < 5; i++) {
            deckModel.addCardToSide("Battle Ox");
        }
        new Player("me", deckModel, true, 1);
        new Player("me2", deckModel, false, 1);
        GameMatController.onlineUser = "me";
    }

    @Test
    public void run() {
        String input = "menu exit";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        assertEquals(0, GameMatController.run("me","me2"));
    }

    @Test
    public void commandController(){
        MainMenuController.username2 = "Guy2";
        run();
        assertEquals(0,GameMatController.commandController("menu exit"));
        assertEquals(1,GameMatController.commandController("select --monster 5 --opponent"));
        assertEquals(2,GameMatController.commandController("select --monster 2"));
        assertEquals(3,GameMatController.commandController("select --opponent --monster 1"));
        assertEquals(4,GameMatController.commandController("select --spell 1 --opponent"));
        assertEquals(5,GameMatController.commandController("select --spell 1"));
        assertEquals(6,GameMatController.commandController("select --opponent --spell 1"));
        assertEquals(7,GameMatController.commandController("s -f"));
        assertEquals(8,GameMatController.commandController("select --field --opponent"));
        assertEquals(9,GameMatController.commandController("select --hand 1"));
        assertEquals(10,GameMatController.commandController("select -d"));
        assertEquals(11,GameMatController.commandController("next phase"));
        assertEquals(12,GameMatController.commandController("summon"));
        assertEquals(13,GameMatController.commandController("set"));
//        assertEquals(14,GameMatController.commandController(""));
        assertEquals(15,GameMatController.commandController("flip-summon"));
//        assertEquals(16,GameMatController.commandController(""));
        assertEquals(17,GameMatController.commandController("attack direct"));
        assertEquals(18,GameMatController.commandController("activate effect"));
        System.setIn( new ByteArrayInputStream("back".getBytes()));
        assertEquals(19,GameMatController.commandController("card show --selected"));
        System.setIn( new ByteArrayInputStream("back".getBytes()));
        assertEquals(21,GameMatController.commandController("show graveyard"));
        System.setIn( new ByteArrayInputStream("no".getBytes()));
        assertEquals(22,GameMatController.commandController("show graveyard --opponent"));
        System.setIn( new ByteArrayInputStream("back".getBytes()));
        assertEquals(23,GameMatController.commandController("show main deck"));
        System.setIn( new ByteArrayInputStream("back".getBytes()));
        assertEquals(24,GameMatController.commandController("show side deck"));
        System.setIn( new ByteArrayInputStream("back".getBytes()));
        assertEquals(25,GameMatController.commandController("show my hand"));
        assertEquals(26,GameMatController.commandController("increase --LP 12133"));
        assertEquals(27,GameMatController.commandController(""));
        System.setIn( new ByteArrayInputStream("menu exit".getBytes()));
        assertEquals(0,GameMatController.commandController("surrender"));
        System.setIn( new ByteArrayInputStream("menu exit".getBytes()));
        assertEquals(0,GameMatController.commandController("duel set-winner me"));
        System.setIn( new ByteArrayInputStream("menu exit".getBytes()));
        assertEquals(0,GameMatController.commandController("duel set-winner me2"));

    }

    @Test
    public void increaseLP() {
        int life = Player.getPlayerByName("me").getLifePoint();
        GameMatController.increaseLP(3, "me");
        assertEquals(life + 3, Player.getPlayerByName("me").getLifePoint());
    }

    @Test
    public void getRivalUser() {
        GameMatController.rivalUser = "me2";
        assertEquals("me2", GameMatController.getRivalUser());
    }

    @Test
    public void getMatcher() {
        GameMatController.rivalUser = "me2";
        assertTrue(GameMatController.getMatcher("duel  set-winner  me2", "duel \\s*set-winner \\s*me2").find());
    }

    @Test
    public void getPermission() {
        final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ByteArrayOutputStream show = new ByteArrayOutputStream();
        System.setOut(new PrintStream(show));
        String input = "no";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        GameMatController.getPermission();
        assertNotEquals("Your opponent want to see your graveyard. Do you give him permission? (yes/no)" + "\n" +
                "Oops! You dont have permission to see your rival graveyard!\n" + "me, please continue the game!", show.toString().substring(0, show.toString().length() - 2));

    }

    @Test
    public void selectMonsterCard() {
        GameMatController.selectMonsterCard(1, true);
        final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ByteArrayOutputStream show = new ByteArrayOutputStream();
        System.setOut(new PrintStream(show));
        assertNotEquals("no card found in the given position", show.toString().substring(0, show.toString().length()));
        new MonsterZoneCard("me", "Battle OX", "DH", false, true);
        GameMatController.selectMonsterCard(1, true);
        final ByteArrayOutputStream outContent1 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent1));
        ByteArrayOutputStream show1 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(show1));
        assertNotEquals("card selected", show1.toString().substring(0, show1.toString().length()));
        GameMatController.rivalUser = "me2";
        GameMatController.selectMonsterCard(1, false);
        final ByteArrayOutputStream outContent2 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent2));
        ByteArrayOutputStream show2 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(show2));
        assertNotEquals("no card found in the given position", show2.toString().substring(0, show2.toString().length()));
        new MonsterZoneCard("me2", "Battle OX", "DH", false, true);
        GameMatController.selectMonsterCard(1, false);
        final ByteArrayOutputStream outContent3 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent3));
        ByteArrayOutputStream show3 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(show1));
        assertNotEquals("card selected", show3.toString().substring(0, show3.toString().length()));

    }

    @Test
    public void selectSpellCard() {
        GameMatController.selectSpellCard(1, true);
        final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ByteArrayOutputStream show = new ByteArrayOutputStream();
        System.setOut(new PrintStream(show));
        assertNotEquals("no card found in the given position", show.toString().substring(0, show.toString().length()));

        new SpellTrapZoneCard("me", "Trap Hole", "H");
        GameMatController.selectSpellCard(1, true);
        final ByteArrayOutputStream outContent1 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent1));
        ByteArrayOutputStream show1 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(show1));
        assertNotEquals("card selected", show1.toString().substring(0, show1.toString().length()));

        GameMatController.rivalUser = "me2";
        GameMatController.selectSpellCard(1, false);
        final ByteArrayOutputStream outContent2 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent2));
        ByteArrayOutputStream show2 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(show2));
        assertNotEquals("no card found in the given position", show2.toString().substring(0, show2.toString().length()));

        new SpellTrapZoneCard("me2", "Trap Hole", "H");
        GameMatController.selectSpellCard(1, false);
        final ByteArrayOutputStream outContent3 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent3));
        ByteArrayOutputStream show3 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(show1));
        assertNotEquals("card selected", show3.toString().substring(0, show3.toString().length()));

    }

    @Test
    public void selectFieldCard() {
        GameMatController.selectFieldCard(true);
        final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ByteArrayOutputStream show = new ByteArrayOutputStream();
        System.setOut(new PrintStream(show));
        assertNotEquals("invalid selection", show.toString().substring(0, show.toString().length()));

        GameMatModel.getGameMatByNickname("me").addToFieldZone("Trap Hole", "H");
        GameMatController.selectFieldCard(true);
        final ByteArrayOutputStream outContent1 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent1));
        ByteArrayOutputStream show1 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(show1));
        assertNotEquals("card selected", show1.toString().substring(0, show1.toString().length()));


        GameMatController.rivalUser = "me2";
        GameMatController.selectFieldCard(false);
        final ByteArrayOutputStream outContent3 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent3));
        ByteArrayOutputStream show3 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(show));
        assertNotEquals("invalid selection", show3.toString().substring(0, show3.toString().length()));

        GameMatModel.getGameMatByNickname("me2").addToFieldZone("Trap Hole", "H");
        GameMatController.selectFieldCard(false);
        final ByteArrayOutputStream outContent4 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent4));
        ByteArrayOutputStream show4 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(show1));
        assertNotEquals("card selected", show4.toString().substring(0, show4.toString().length()));
    }

    @Test
    public void selectHandCard() {
        GameMatController.selectHandCard(1);
        final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ByteArrayOutputStream show = new ByteArrayOutputStream();
        System.setOut(new PrintStream(show));
        assertNotEquals("card selected", show.toString().substring(0, show.toString().length()));

    }

    @Test
    public void selectDelete() {
        GameMatController.rivalUser = "me2";
        GameMatController.selectDelete();
        final ByteArrayOutputStream outContent2 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent2));
        ByteArrayOutputStream show2 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(show2));
        assertNotEquals("no card is selected yet", show2.toString().substring(0, show2.toString().length()));

        GameMatController.selectMonsterCard(1, false);
        GameMatController.selectDelete();
        final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ByteArrayOutputStream show = new ByteArrayOutputStream();
        System.setOut(new PrintStream(show));
        assertNotEquals("card deselected", show.toString().substring(0, show.toString().length()));

        GameMatController.selectMonsterCard(1, true);
        GameMatController.selectDelete();
        final ByteArrayOutputStream outContent1 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent1));
        ByteArrayOutputStream show1 = new ByteArrayOutputStream();
        System.setOut(new PrintStream(show1));
        assertNotEquals("card deselected", show1.toString().substring(0, show1.toString().length()));


    }

    @Test
    public void errorOfNoCardSelected() {
        GameMatController.selectedOwnCard="";
        assertFalse(GameMatController.errorOfNoCardSelected("own"));
        new MonsterZoneCard("me", "Battle OX", "DH", false, true);
        GameMatController.selectMonsterCard(1, true);
        assertTrue(GameMatController.errorOfNoCardSelected("own"));

        GameMatController.rivalUser = "me2";
        GameMatController.selectedRivalCard="";
        assertFalse(GameMatController.errorOfNoCardSelected("rival"));
        new MonsterZoneCard("me2", "Battle OX", "DH", false, true);
        GameMatController.selectMonsterCard(1, false);
        assertTrue(GameMatController.errorOfNoCardSelected("rival"));
    }

    //////////////////////////////////////////////////////////////
    @Test
    public void errorOfInvalidSelection() {
        assertFalse(GameMatController.errorOfInvalidSelection(6, "Monster"));
        assertTrue(GameMatController.errorOfInvalidSelection(1, "Monster"));
        assertFalse(GameMatController.errorOfInvalidSelection(0, "Monster"));
        assertFalse(GameMatController.errorOfInvalidSelection(6, "Spell"));
        assertTrue(GameMatController.errorOfInvalidSelection(1, "Spell"));
        assertFalse(GameMatController.errorOfInvalidSelection(14, "Hand"));
        assertTrue(GameMatController.errorOfInvalidSelection(1, "Hand"));
    }

    @Test
    public void summon() {

    }

    @Test
    public void summonInHand() {
    }

    @Test
    public void summonInHandSuccessfully() {
    }

    @Test
    public void summonInMonsterZone() {
    }

    @Test
    public void summonInMonsterZoneSuccessfully() {
    }

    @Test
    public void changeMonsterPosition() {
    }

    @Test
    public void set() {
    }

    @Test
    public void addToMonsterZoneCard() {
    }

    @Test
    public void addToSpellTrapZoneCard() {
        SpellTrapZoneCard trap = new SpellTrapZoneCard("me", "Trap Hole", "O");
        Assert.assertEquals(trap, SpellTrapZoneCard.getSpellCardByAddress(1, "me"));
    }

    @Test
    public void errorOfWrongPhase() {
    }

    @Test
    public void errorOfFullZone() {
    }

    @Test
    public void specialSummon() {
    }

    @Test
    public void ritualSummon() {
    }

    @Test
    public void tributeMonster() {
    }

    @Test
    public void getAddressOfTributeMonster() {
    }

    @Test
    public void flipSummon() {
    }

    @Test
    public void attack() {
    }

    @Test
    public void attackDirect() {
    }

    @Test
    public void checkForSetTrapToActivateInRivalTurn() {
    }

    @Test
    public void checkForQuickSpellInRivalTurn() {
    }

    @Test
    public void activateTrapEffect() {
    }

    @Test
    public void changePhase() {
    }

    @Test
    public void changeTurn() {
    }

    @Test
    public void endGame() {
    }

    @Test
    public void exchangeCard() {
    }

    @Test
    public void showGameBoard() {
    }

    @Test
    public void showSelectedCard() {
    }

    @Test
    public void backCommand() {
    }

    @Test
    public void activateSpellEffect() {
    }

    @Test
    public void chooseSpellEffectController() {
    }

    @Test
    public void getAddressOfRelatedMonster() {
    }

    @Test
    public void getResponseForEquipSpell() {
    }

    @Test
    public void checkForSpellAbsorption() {
    }

    @Test
    public void checkForMessengerOfPeace() {
    }

    @Test
    public void checkForSupplySquad() {
    }
}