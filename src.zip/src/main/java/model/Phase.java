package model;


public enum Phase {
    Draw_Phase,
    Standby_Phase,
    Main_Phase1,
    Battle_Phase,
    Main_Phase2,
    End_Phase
}
