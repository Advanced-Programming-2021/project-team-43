package controller;

import org.junit.Test;

import static org.junit.Assert.*;

public class PickFirstPlayerTest {

    @Test
    public void chose() {
    }
}