package controller;

import org.junit.Test;

import static org.junit.Assert.*;

public class SpellEffectTest {

    @Test
    public void normalEffectController() {
    }

    @Test
    public void quickPlayEffectController() {
    }

    @Test
    public void equipEffectController() {
    }

    @Test
    public void fieldEffectController() {
    }

    @Test
    public void terraforming() {
    }

    @Test
    public void raigeki() {
    }

    @Test
    public void returnPermission() {
    }

    @Test
    public void spellAbsorption() {
    }

    @Test
    public void messengerOfPeace() {
    }

    @Test
    public void returnPermissionMessenger() {
    }

    @Test
    public void twinTwisters() {
    }
}