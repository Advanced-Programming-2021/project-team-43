package controller;

import org.junit.Test;

import static org.junit.Assert.*;

public class TrapEffectTest {

    @Test
    public void magicCylinder() {
    }

    @Test
    public void mirrorForce() {
    }

    @Test
    public void mindCrush() {
    }

    @Test
    public void torrentialTribute() {
    }

    @Test
    public void timeSeal() {
    }

    @Test
    public void solemnWarning() {
    }

    @Test
    public void magicJammer() {
    }

    @Test
    public void callOfTheHaunted() {
    }
}